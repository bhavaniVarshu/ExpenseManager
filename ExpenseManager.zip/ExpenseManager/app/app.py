from flask import Flask, render_template, redirect, request, session
import mysql.connector
import os

app = Flask(__name__, template_folder='templates')
app.secret_key = os.urandom(24)


# Configure MySQL database connection
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="CodeExpense",
    connect_timeout=1000
)
dbconn = mydb.cursor(dictionary=True)  # dict format

# Login route
@app.route('/', methods=['GET', 'POST'])
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']  
        password = request.form['password']
        dbconn.execute('SELECT * FROM users WHERE username = %s AND password = %s', (username, password))
        user = dbconn.fetchone()
        if user:
            session['username'] = username
            session['announcement'] = "Welcome to the CODE Expense Manager, {}!".format(username)  # Set announcement upon successful login
            return redirect('/dashboard') 
        else:
            return 'Invalid username or password'
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return render_template('dashboard/layout.html')
    else:
        return redirect('/login') 

@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('announcement', None)
    return redirect('/login')

@app.route("/definition")
def fetch_title():
    try:
        cur = mydb.cursor(dictionary=True)
        cur.execute("SELECT id, title FROM title ORDER BY title;")
        title = cur.fetchall()
        cur.close()
        
        cur = mydb.cursor(dictionary=True)
        cur.execute("SELECT t.title, d.type, d.id, d.status FROM definition d JOIN title t ON t.id = d.title ORDER BY t.title, d.type;")
        definition_list = cur.fetchall()
        cur.close()
        
        if title:
            return render_template('dashboard/definition.html', title=title, definition_list=definition_list)
        else:
            return render_template('dashboard/definition.html')
    except Exception as e:
        return "An error occurred: {}".format(str(e))    
    
@app.route('/add_definition', methods=['POST'])
def add_definition():
    if request.method == 'POST':
        try:
            title = request.form['title']
            type = request.form['type']

            # Execute SQL insert query
            dbconn.execute('INSERT INTO definition (title, type, status) VALUES (%s, %s, 1)', (title, type))
            mydb.commit()

            return redirect('/definition')
        except Exception as e:
            return "An error occurred: {}".format(str(e))
                
@app.route('/projects', methods=['GET', 'POST'])
def projects():
    if request.method == 'POST':
        try:
            project_category = request.form['project_category']
            project_type = request.form['project_type']
            project_no = request.form['project_no']
            project_title = request.form['project_title']
            coordinator = request.form['coordinator']
            department = request.form['department']
            start_date = request.form['start_date']
            end_date = request.form['end_date']
            status = request.form['status']


# Fetch options from definition table
            cur = mydb.cursor(dictionary=True)
            cur.execute("SELECT type FROM definition WHERE title = 2;")
            project_categories = cur.fetchall()
            cur.execute("SELECT type FROM definition WHERE title = 1;")
            project_types = cur.fetchall()
            print(project_types)
            cur.close()
            
            
            # Execute SQL insert query
            dbconn.execute('INSERT INTO project (project_category, project_type, project_no, project_title, coordinator, coordinator, start_date, end_date, status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)', (project_category, project_type, project_no, project_title, coordinator, department, start_date, end_date, status))
            mydb.commit()

            dbconn.execute('SELECT * FROM project')
            projects = dbconn.fetchall()
            
            return render_template('dashboard/project.html', projects=projects, project_categories=project_categories, project_types=project_types)
            
        except Exception as e:
             return "An error occurred: {}".format(str(e))
    else:
        try:
            # Fetch all projects
            dbconn.execute('SELECT * FROM project')
            projects = dbconn.fetchall()

            return render_template('dashboard/project.html', projects=projects)
        except Exception as e:
            return "An error occurred: {}".format(str(e))  

if __name__ == '__main__':
    app.run(debug=True)

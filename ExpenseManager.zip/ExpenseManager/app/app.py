from flask import Flask, render_template, redirect, request, session
import mysql.connector
import os

app = Flask(__name__, template_folder='templates')
app.secret_key = os.urandom(24)


# Configure MySQL database connection
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="CodeExpense",
    connect_timeout=1000
)
dbconn = mydb.cursor(dictionary=True)  # dict format

# Login route
@app.route('/', methods=['GET', 'POST'])
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']  
        password = request.form['password']
        dbconn.execute('SELECT * FROM users WHERE username = %s AND password = %s', (username, password))
        user = dbconn.fetchone()
        if user:
            session['username'] = username
            session['announcement'] = "Welcome to the CODE Expense Manager, {}!".format(username)  # Set announcement upon successful login
            return redirect('/dashboard') 
        else:
            return 'Invalid username or password'
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        project_types = fetch_project_types()
        project_data = {}
        for project_type in project_types:
            income = calculate_total_income(project_type)
            expense = calculate_total_expense(project_type)
            project_data[project_type] = {'income': income, 'expense': expense}

        return render_template('dashboard/layout.html', project_data=project_data)
    else:
        return redirect('/login')

def fetch_project_types():
    dbconn.execute('SELECT DISTINCT project_type FROM project')
    project_types = dbconn.fetchall()
    return [project_type['project_type'] for project_type in project_types]

def calculate_total_income(project_type):
    dbconn.execute('select round(sum(invoiceamount),2) as total_income FROM income WHERE income_projectcategory = %s', (project_type,))
    result = dbconn.fetchone()
    total_income = result['total_income'] if result['total_income'] else 0
    return total_income

def calculate_total_expense(project_type):
    dbconn.execute('select sum(exp_amount) as total_expense FROM expense WHERE exp_pcategory = %s', (project_type,))
    result = dbconn.fetchone()
    total_expense = result['total_expense'] if result['total_expense'] else 0
    return total_expense

@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('announcement', None)
    return redirect('/login')

@app.route("/definition")
def fetch_title():
    try:
        cur = mydb.cursor(dictionary=True)
        cur.execute("SELECT id, title FROM title ORDER BY title;")
        title = cur.fetchall()
        cur.close()
        
        cur = mydb.cursor(dictionary=True)
        cur.execute("SELECT t.title, d.type, d.id, d.status FROM definition d JOIN title t ON t.id = d.title ORDER BY t.title, d.type;")
        definition_list = cur.fetchall()
        cur.close()
        
        if title:
            return render_template('dashboard/definition.html', title=title, definition_list=definition_list)
        else:
            return render_template('dashboard/definition.html')
    except Exception as e:
        return "An error occurred: {}".format(str(e))    
    
@app.route('/add_definition', methods=['POST'])
def add_definition():
    if request.method == 'POST':
        try:
            title = request.form['title']
            type = request.form['type']

            # Execute SQL insert query
            dbconn.execute('INSERT INTO definition (title, type, status) VALUES (%s, %s, 1)', (title, type))
            mydb.commit()

            return redirect('/definition')
        except Exception as e:
            return "An error occurred: {}".format(str(e))
                
@app.route('/projects', methods=['GET', 'POST'])
def projects():
    cur = mydb.cursor(dictionary=True)
    cur.execute("SELECT type FROM definition WHERE title = 2;")
    project_categories = cur.fetchall()
    cur.execute("SELECT type FROM definition WHERE title = 1;")
    project_types = cur.fetchall()
    cur.execute("SELECT type FROM definition WHERE title = 3;")
    project_status = cur.fetchall()
    cur.close()
    if request.method == 'POST':
        try:
            project_category = request.form['project_category']
            project_type = request.form['project_type']
            project_no = request.form['project_no']
            project_title = request.form['project_title']
            coordinator = request.form['coordinator']
            department = request.form['department']
            startdate = request.form['startdate']
            enddate = request.form['enddate']
            status = request.form['status']


# Fetch options from definition table
            
            
            
            # Execute SQL insert query
            dbconn.execute('INSERT INTO project (project_category, project_type, project_no, project_title, coordinator, department, startdate, enddate, status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)', (project_category, project_type, project_no, project_title, coordinator, department, startdate, enddate, status))
            mydb.commit()

            dbconn.execute('SELECT * FROM project')
            projects = dbconn.fetchall()
            
            return render_template('dashboard/project.html', projects=projects, project_categories=project_categories, project_types=project_types, project_status=project_status)
            
        except Exception as e:
             return "An error occurred: {}".format(str(e))
    else:
        try:
            # Fetch all projects
            dbconn.execute('SELECT * FROM project')
            projects = dbconn.fetchall()

            return render_template('dashboard/project.html', projects=projects,project_categories=project_categories, project_types=project_types, project_status=project_status)
        except Exception as e:
            return "An error occurred: {}".format(str(e))  

@app.route('/edit_project', methods=['POST'])
def edit_project():
    if request.method == 'POST':
        try: 
            project_id = request.form['id']           
            status = request.form['status']
            dbconn.execute('UPDATE project SET status = %s WHERE id = %s',
                           (status, project_id))
            mydb.commit()
            # Redirect back to the projects page after editing
            return redirect('/projects')
        except Exception as e:
            return "An error occurred while editing project: {}".format(str(e))

@app.route('/delete_project', methods=['POST'])
def delete_project():
    if request.method == 'POST':
        try:
            # Retrieve the project ID to be deleted
            project_id = request.form['id']

            # Delete the project from the database
            dbconn.execute('DELETE FROM project WHERE id = %s', (project_id,))
            mydb.commit()

            # Redirect back to the projects page after deleting
            return redirect('/projects')
        except Exception as e:
            return "An error occurred while deleting project: {}".format(str(e))

@app.route('/income', methods=['GET', 'POST'])
def incomes():
    cur = mydb.cursor(dictionary=True)
    cur.execute("SELECT project_no FROM project;")
    income_project = cur.fetchall()
    cur.execute("SELECT type FROM definition WHERE title = 1;")
    income_category = cur.fetchall()
    cur.execute("SELECT type FROM definition WHERE title = 4;")
    income_from = cur.fetchall()
    cur.execute("SELECT type FROM definition WHERE title = 2;")
    income_projecttype = cur.fetchall()
    cur.close()
    if request.method == 'POST':
        try:
            income_type = request.form['income_type']
            income_projecttype = request.form['income_projecttype']
            income_projectno = request.form['income_projectno']
            income_projectcategory = request.form['income_projectcategory']
            invoiceno = request.form['invoiceno']
            particulars = request.form['particulars']
            invoiceamount = request.form['invoiceamount']
            tdsamount = request.form['tdsamount']
            bank_received = request.form['bank_received']
            gst = request.form['gst']
            code_oh = request.form['code_oh']
            icsr_oh = request.form['icsr_oh']
            corpus = request.form['corpus']
            ddf = request.form['ddf']
            admin_oh = request.form['admin_oh']
            netamount = request.form['netamount']
            receiptno = request.form['receiptno']
            receipt_date = request.form['receipt_date']
            invoicelink = request.form['invoicelink']
            banklink = request.form['banklink']
            

            # Execute SQL insert query
            dbconn.execute('INSERT INTO income (income_type, income_projecttype, income_projectno, income_projectcategory, invoiceno, particulars, invoiceamount, tdsamount, bank_received, gst, code_oh, icsr_oh, corpus, ddf, admin_oh, netamount, receiptno, receipt_date, invoicelink, banklink) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)', (income_type, income_projecttype, income_projectno, income_projectcategory, invoiceno, particulars, invoiceamount, tdsamount, bank_received, gst, code_oh, icsr_oh, corpus, ddf, admin_oh, netamount, receiptno, receipt_date, invoicelink, banklink ))
            mydb.commit()

            dbconn.execute('SELECT * FROM income')
            incomes = dbconn.fetchall()
            
            return render_template('dashboard/income.html', incomes=incomes, income_category=income_category, income_from=income_from,income_project=income_project, income_projecttype=income_projecttype)
            
        except Exception as e:
             return "An error occurred: {}".format(str(e))
    else:
        try:
            # Fetch all projects
            dbconn.execute('SELECT * FROM income')
            incomes = dbconn.fetchall()

            return render_template('dashboard/income.html', incomes=incomes, income_category=income_category, income_from=income_from, income_project=income_project, income_projecttype=income_projecttype)
        except Exception as e:
            return "An error occurred: {}".format(str(e))  

@app.route('/expense', methods=['GET', 'POST'])
def expenses():
    cur = mydb.cursor(dictionary=True)
    cur.execute("SELECT project_no FROM project;")
    expense_project = cur.fetchall()
    cur.execute("SELECT type FROM definition WHERE title = 1;")
    expense_category = cur.fetchall()
    cur.execute("SELECT type FROM definition WHERE title = 2;")
    expense_projecttype = cur.fetchall()
    cur.execute("SELECT type FROM definition WHERE title = 6;")
    expense_heads = cur.fetchall()
    cur.close()
    if request.method == 'POST':
        try:
            exp_head = request.form['exp_head']
            exp_ptype = request.form['exp_ptype']
            exp_pno = request.form['exp_pno']
            exp_pcategory = request.form['exp_pcategory']
            vendorname = request.form['vendorname']
            billno = request.form['billno']
            billdate = request.form['billdate']
            exp_amount = request.form['exp_amount']
            exp_tapallink = request.form['exp_tapallink']
            exp_commitno = request.form['exp_commitno']
            
            # Execute SQL insert query
            dbconn.execute('INSERT INTO expense (exp_head, exp_ptype, exp_pno, exp_pcategory, vendorname, billno, billdate, exp_amount, exp_tapallink, exp_commitno) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)', (exp_head, exp_ptype, exp_pno, exp_pcategory, vendorname, billno, billdate, exp_amount, exp_tapallink, exp_commitno ))
            mydb.commit()

            dbconn.execute('SELECT * FROM expense')
            expenses = dbconn.fetchall()
            
            return render_template('dashboard/expense.html', expenses=expenses, expense_project=expense_project, expense_category=expense_category,expense_projecttype=expense_projecttype, expense_heads=expense_heads)
            
        except Exception as e:
             return "An error occurred: {}".format(str(e))
    else:
        try:
            # Fetch all projects
            dbconn.execute('SELECT * FROM expense')
            expenses = dbconn.fetchall()

            return render_template('dashboard/expense.html', expenses=expenses, expense_project=expense_project, expense_category=expense_category,expense_projecttype=expense_projecttype, expense_heads=expense_heads)
        except Exception as e:
            return "An error occurred: {}".format(str(e))  

    
if __name__ == '__main__':
    app.run(debug=True,port=8080)
